//EX1

    var num = 1;
        num += 12;
        num -= 14;
        num *= 5;
        num /= 7;
        num ++;
        num --;
        num += 7;
        num -= 18;
        num *= 10;
        num /= 15;

console.log(num);

//EX2

    var hour = 10;
        min = 11;
        sec = 12;

console.log ( hour + ':' + min + ':' + sec);

//EX3

    var str = 'abcde';

if (str[0] == 'a') {
   console.log('Верно');
} else {
   console.log('Неверно');
}

//EX4

    var str = "В некиим царстве, в некиим государстве жил-был богатый купец, именитый человек";

console.log ( str[47] + str[48] + str[49] + str[50] + str[51] + str[52] + str[53] + str[54] + str[55]
             + str[56] + str[57] + str[58] + str[59]);

//EX5

    var str = '123';
        b = Number(str[0]) + Number(str[1]) + Number(str[2]);

console.log(b);

//EX6

    var a = 11;

if (a == 10) {
    console.log('Верно');
} else {
    console.log('Неверно');
}

//EX7

    var a = 'test';

if (a == 'test') {
    console.log('Верно');
} else {
    console.log('Неверно');
}

//EX8

    var a = 10;
        b = 2;
        c = a + b;
        d = a - b;

if (a <= 1 || b >= 3) {
    console.log(c);
} else {
    console.log(d);
}

//EX9

    var l = prompt('Ваш логин');
        n = prompt('Ваше имя');
        p = prompt('Ваш пароль');

if (l == 1 && n == 'Ярослав' && p == 111) {
    console.log('Добро Пожаловать!');
} else {
    console.log('Вход невозможен');
}

//EX10

    var month = parseInt(prompt('Месяц'));
        
if (month == 1 || month == 2 || month == 12) {
    season = 1;
} else if (month == 4 || month == 5 || month == 3) {
    season = 2;
} else if (month == 6 || month == 7 || month == 8) {
    season = 3;
} else if (month == 9 || month == 10 || month == 11) {
    season = 4;
}

switch (season) {
    case 1 :
        console.log('Зима')
break;
    case 2 :
        console.log('Весна')
break;
    case 3 :
        console.log('Лето')
break;
    case 4 :
        console.log('Осень')
break;
}
    

