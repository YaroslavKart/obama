//EX1

var age = prompt('Ваш Возраст?', 18),
access = (age == 18) ? "Мне 18 лет" : "Произошёл взлом";

console.log (access);

var name = prompt('Ваше имя?', 'Ярослав'),
access = (name == 'Ярослав') ? "Меня зовут Ярослав" : "Взлом продолжается";

console.log (access); 

var city = prompt('Ваш город проживания?', 'Минск'),
access = (city == 'Минск') ? "Я проживаю в Минске" : "Хакеры атакуют";

console.log (access);

var phone = prompt('Ваш номер телефона?', 'Без подсказок'),
access = (phone == 375297769774) ? "Мой номер телефона 375297769774" : "Взломщик найден";

console.log (access);

var email = prompt('Ваша почта?', 'Напишите сами'),
access = (email == 'kartalevskii.mail') ? "Моя почта kartalevskii.mail" : "Поиск адреса взломщика...";

console.log (access);

var company = prompt('Ваша компания?', 'Напишите компанию'),
access = (company == 'myitschool.by') ? "Проверяйте дальше, хорошего вечера" : "Выезжаем";

console.log (access);

//EX2

var date = prompt ('Ваша дата рождения?', 1990.9);
var  a = 2020.04;
var age = Math.floor(a - date) / 1;

console.log ( 'Ваш возраст ' + age + ' лет');   

//EX3

var str = prompt('Введите 6 цифр');

if ((+str[0] + +str[1] + +str[2]) == (+str[3] + +str[4] + +str[5])) {
   console.log('Да');
} else {
   console.log('Нет');
}

//EX4

var a = prompt('Введите любое число');

if (a > 0) {
   console.log('Верно');
} else {
   console.log('Неверно');
}

//EX5

var a = prompt('Введите первое любое число');
var b = prompt ('Введите второе любое число');
var s = +a + +b;
var f = +a - +b;
var m = +a * +b;
var k = +a / +b;
var x = Math.pow((+a + +b),2);

console.log (s, f, m, k, x);

//EX6

(a > 2) && (a < 11) && (b >= 6) && (b < 14) ? console.log('Верно, подходит') : console.log('Это совсем не то');

//EX7

    var n = prompt('Введите сколько сейчас минут на ваших часах');

if  (n > 59)  {
    console.log('Вы ввели что-то не так');
}   else if (n >= 45)  {
        console.log('Четвертая четверть часа');
}   else if (n >= 30) {
    console.log('Третья четверть часа');
}   else if (n >= 15) {
    console.log('Вторая четверть часа');
}   else if (n >= 0) {
    console.log('Первая четверть часа'); 
}   else if (n < -1)  {
    console.log('Вы ввели что-то не так');
}   else {
    console.log(n); 
}  

//EX8

    var day = prompt('Введите число месяца');

if  (day > 31)  {
        console.log('Вы ввели что-то не так');
}   else if (day >= 21)  {
            console.log('Третья декада');
}   else if (day >= 11) {
        console.log('Вторая декада');
}   else if (day >= 1) {
        console.log('Первая декада');
}   else if (day < 1)  {
        console.log('Вы ввели что-то не так');
}   else {
        console.log(day); 
} 

//EX9
    var day = prompt('Мы переведем ваши Дни в > года, месяцы, дни, часы, минуты и секунды!');
    var month = day / 30.4375;
    var year = month / 12;
    var week = day / 7;
    var hour = day *24;
    var min =  hour * 60;
    var s = min * 60;

console. log (day + "  это - ", year + " лет", month + " месяцев", week + "недель", hour + " часов", min + " минут", s + " cекунд");

//EX10

    var day = prompt('Введите число дня года');

if  (day > 366)  {
        console.log('Вы ввели что-то не так');

}   else if (day >= 335)  {
            console.log('Это декабрь, Зима');

}   else if (day >= 305) {
        console.log('Это ноябрь, Осень');

}   else if (day >= 275) {
        console.log('Это октябрь, Осень');

}   else if (day >= 245)  {
        console.log('Это сентябрь, Осень');

}   else if (day >= 215) {
        console.log('Это август, Лето');

}   else if (day >= 184) {
        console.log('Это июль, Лето');

}   else if (day >= 153)  {
        console.log('Это июнь, Лето');

}   else if (day >= 122) {
        console.log('Это май, Весна');

}   else if (day >= 91) {
        console.log('Это апрель, Весна');

}   else if (day >= 60)  {
        console.log('Это март, Весна');

}   else if (day >= 31) {
        console.log('Это февраль, Зима');

}   else if (day >= 1) {
        console.log('Это январь, Зима');

}   else if (day <= 0 )  {
        console.log('Вы ввели что-то не так');

}   else {
        console.log(day); 
} 




    

