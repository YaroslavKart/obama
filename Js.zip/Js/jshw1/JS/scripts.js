//EX1

    var str = "Привет",
        sum = 123,
        num =  15.8,
        txt = "true",
        flag = true;

console.log(typeof str);
console.log(typeof sum);
console.log(typeof num);
console.log(typeof txt);
console.log(typeof flag);

//EX2

    var a1 = 5 % 3,
        a2 = 3 % 5,     
        a3 = 5 + '3',
        a4 = '5' - 3,
        a5 = 75 + 'кг',
        a6 = 785 * 653,
        a7 = 100 / 25,
        a8 = 0 * 0,
        a9 = 0 / 2,
        a10 = 89 / 0,
        a11 = 98 + 2,
        a12 = 5 - 98,
        a13 = (8 + 56 * 4) / 5,
        a14 = (9 - 12) * 7 / (5 + 2),
        a15 = +"123",
        a16 = 1 || 2,
        a17 = false || true,
        a18 = true > 0;
        
console.log (a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18);
  
console.log (typeof a1, typeof a2, typeof a3, typeof a4, typeof a5, typeof a6, typeof a7, typeof a8, typeof a9, 
            typeof a10, typeof a11, typeof a12, typeof a13, typeof a14, typeof a15, typeof a16, typeof a17, typeof a18);

//EX3

    var height = 23,
        width = 10;

console.log (height * width + 'см');  

//EX4

    var height = 10,
        pi = 3.14,
        VCilindra =  (height * a7 * pi) + "м";

console.log (VCilindra);

//EX5

    var r = 5,
        r2 = Math.pow(5,2),
        SKruga = (r2 * pi);

console.log (SKruga + 'см');

//EX6

    var a = 5,
        b = 7,
        STrap = ((a + b) / 2) * height;

console.log (STrap + 'см');

//EX7

    var S = 2,
        p = 0.1,
        years = 5,
        Pereplata = (S * p) * years;
        
console.log (Pereplata + 'млн. руб.');      

 //EX8

    var a = 8,
        b = 3,
        x = ((16 - a) / 2) + b;

console.log (x);

//EX9

console.log
 (" Бывало, спит у ног собака,\n\r костёр занявшийся гудит,\n\r и женщина из полумрака\n\r глазами зыбкими глядит.\n\r\n\r Потом под пихтаю приляжет\n\r на куртку рыжую мою\n\r и мне, задумчивая, скажет:\n\r\n\r \"А ну-ка, спой!\" - и я пою. ")

//EX10

    var a1 = "индо земля зашаталась под ногами-и вырос,",
        a2 = "и заревел он голосом диким...",
        a3 = "блеснула молния и ударил гром,",
        a4 = "а так какое-то чудище, страшное и мохнатое,",
        a5 = "как-будто из-под земли, перед купцом:",
        a6 = "Он подошёл и сорвал аленький цветочек.",
        a7 = "звер не зверь, человек не человек,",
        a8 = "В ту же минуту, безо всяких туч,",
        text = a6 + a8 + a3 + a5 + a1 + a7 + a4 + a2;

console.log (text);       
        








        



